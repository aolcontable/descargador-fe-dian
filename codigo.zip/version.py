"""Versión de la app. CODE_VERSION se auto-actualiza por internet; RUNTIME_VERSION
solo cambia cuando hay que re-descargar el paquete completo (navegador, etc.)."""
CODE_VERSION = 24       # sube con cada cambio de código (se actualiza solo)
RUNTIME_VERSION = 1     # sube solo en updates grandes (re-descarga completa)
NOMBRE = "Procesador Xml - Pdf y Excel"
# Texto de esta versión (va al version.json). Subir CODE_VERSION y subirlo a main
# PUBLICA la actualización para todo el equipo: ver README › Publicar una versión.
NOTAS = ("v24 · Vuelve a encontrar los documentos (la DIAN cambió su consulta y la app "
         "veía 0), reintenta cuando la DIAN está saturada en vez de dar 0, y botones "
         "para pausar y cancelar una descarga.")
